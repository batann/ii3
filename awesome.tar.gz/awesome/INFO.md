More info on 

https://github.com/awesomeWM/awesome

https://github.com/lcpz/awesome-copycats.git

https://github.com/lcpz/awesome-freedesktop.git

https://github.com/lcpz/lain.git